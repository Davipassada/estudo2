public class Console {
	public static void main(String[] args) {
		ControleLeilao controle = new ControleLeilao();
		controle.iniciar();
	}
}